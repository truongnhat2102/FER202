import React, { useState, useEffect } from 'react';
import styles from './StudentList.css';


const StudentList = () => {
    const [students, setStudents] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetch('http://localhost:8080/student/list')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => setStudents(data))
            .catch(error => setError(error.message));
    }, []);

    if (error) {
        return <div className={styles.errorMessage}>Error: {error}</div>;
    }

    return (
        <div className={styles.container}>
            <h1 className={styles.title}>Students</h1>
            {students.length > 0 ? (
                <ul className={styles.studentList}>
                    {students.map(student => (
                        <li key={student.id} className={styles.studentItem}>
                            {student.name}  {student.typeStudent.typeStudentName}
                        </li>
                    ))}
                </ul>
            ) : (
                <p>No students found</p>
            )}
        </div>
    );
};

export default StudentList;