import logo from './logo.svg';
import './App.css';
import StudentList from './Component/StudentList';

function App() {
  return (
    <StudentList />
  );
}

export default App;
