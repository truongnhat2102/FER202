# Lab 2

## Documents
- Document: [Click here!!!](Lab2_Build_the_website_interface_BootStrap.docx.pdf)

## Build
### Install dependencies:
```bash
npm install
```
### Run:
```bash
npm run dev
```